package com.lucas.mapper;

import com.lucas.pojo.Users;
import org.springframework.stereotype.Repository;

public interface UsersMapper {
    int insert(Users users);



}
