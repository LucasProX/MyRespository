package com.lucas.service;

import com.lucas.pojo.Users;

public interface UsersService {
    //增加用户
    int insert(Users users);
}
